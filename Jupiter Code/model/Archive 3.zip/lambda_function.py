import os
import io
import boto3
import json
import csv
import pandas as pd
import requests

CLIENT_ID = "83ae548c8bdb40a9a65a4b6e2a174bd6"
CLIENT_SECRET = "9961fe6a1fe94d11a256d13a65b44efb"


AUTH_URL = 'https://accounts.spotify.com/api/token'
base_url = "https://api.spotify.com/v1/"

auth_response = requests.post(AUTH_URL, {
    'grant_type': 'client_credentials',
    'client_id': CLIENT_ID,
    'client_secret': CLIENT_SECRET,
})

final_attributes = []

auth_response_data = auth_response.json()
access_token = auth_response_data["access_token"]

headers = {
    'Authorization': 'Bearer {token}'.format(token=access_token)
}
    
# grab environment variables
ENDPOINT_NAME = 'retro-autopilot-best-model'
runtime= boto3.client('runtime.sagemaker')

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    
    #data = json.loads(json.dumps(event))
    playlist_link = "https://open.spotify.com/playlist/4zmc502dZCnWGbFPckE6rG"
    playlist_id = playlist_link.split("/")
    print(playlist_id)
    playlist = requests.get(base_url+"playlists/"+"4zmc502dZCnWGbFPckE6rG", headers=headers)
    spotify_playlist_output = playlist.json()
    print(spotify_playlist_output)
    
    items = spotify_playlist_output["tracks"]["items"]
    items_array = []
    for item in items:
        id = (item["track"]["id"])
        items_array.append(id)
    
        song_attr = []
    
    for array_item in items_array:
        song_attributes = requests.get(base_url+"audio-features/"+array_item, headers=headers)
        json_attr = song_attributes.json()
        is_retro = True
        song = [
            json_attr["danceability"],
            json_attr["energy"],
            json_attr["key"],
            json_attr["loudness"],
            json_attr["speechiness"],
            json_attr["acousticness"],
            json_attr["instrumentalness"],
            json_attr["liveness"],
            json_attr["valence"],
            json_attr["tempo"],
            json_attr["time_signature"],
            is_retro
        ]
    
        final_attributes.append(song)
    
    payload = json.dumps(final_attributes)
    df = pd.DataFrame.from_dict(payload)
    lines = payload
    # for l in lines[1:2000]:   # Skip header
    #      l = l.split(',')      # Split CSV line into features
    #      label = l[-1]         # Store 'yes'/'no' label
    #      l = l[:-1]            # Remove label
    #      l = ','.join(l)
    # print(payload)
    df.to_csv('tmp.csv')
    
    with open('tmp.csv', 'r') as f:
        l = f.readlines()[1:]
    
    response = runtime.invoke_endpoint(EndpointName=ENDPOINT_NAME,
                                       ContentType='text/csv',
                                       Body=l)
    response = response['Body'].read().decode("utf-8")
    print(response)